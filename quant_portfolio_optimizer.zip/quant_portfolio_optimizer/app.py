import warnings
from datetime import date, timedelta

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
import yfinance as yf
from scipy.optimize import minimize

warnings.filterwarnings("ignore")

TRADING_DAYS = 252
DEFAULT_TICKERS = "AAPL, MSFT, GOOGL, AMZN, NVDA, META, JPM, V, UNH, XOM"
RISK_FREE_RATE = 0.04

st.set_page_config(
    page_title="Quant Portfolio Optimizer",
    page_icon="📈",
    layout="wide",
)

st.title("Quant Portfolio Optimizer")
st.caption("Investment analytics, Monte Carlo simulation, risk-return metrics, and portfolio optimization in one local browser dashboard.")


def parse_tickers(raw_text: str) -> list[str]:
    tickers = [ticker.strip().upper() for ticker in raw_text.split(",") if ticker.strip()]
    return list(dict.fromkeys(tickers))


@st.cache_data(show_spinner=False)
def download_prices(tickers: tuple[str, ...], start: date, end: date) -> pd.DataFrame:
    data = yf.download(
        list(tickers),
        start=start,
        end=end + timedelta(days=1),
        auto_adjust=True,
        progress=False,
        group_by="column",
        threads=True,
    )

    if data.empty:
        return pd.DataFrame()

    if isinstance(data.columns, pd.MultiIndex):
        if "Close" in data.columns.get_level_values(0):
            prices = data["Close"].copy()
        else:
            prices = data.xs("Close", level=1, axis=1).copy()
    else:
        prices = data[["Close"]].copy()
        prices.columns = list(tickers)[:1]

    prices = prices.dropna(axis=1, how="all").ffill().dropna()
    return prices


def calculate_returns(prices: pd.DataFrame) -> pd.DataFrame:
    return prices.pct_change().dropna()


def annualized_metrics(returns: pd.DataFrame) -> tuple[pd.Series, pd.Series, pd.Series]:
    annual_return = returns.mean() * TRADING_DAYS
    annual_volatility = returns.std() * np.sqrt(TRADING_DAYS)
    sharpe = (annual_return - RISK_FREE_RATE) / annual_volatility.replace(0, np.nan)
    return annual_return, annual_volatility, sharpe


def portfolio_performance(weights: np.ndarray, annual_return: pd.Series, cov_matrix: pd.DataFrame) -> tuple[float, float, float]:
    port_return = float(np.dot(weights, annual_return))
    port_volatility = float(np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights))))
    port_sharpe = (port_return - RISK_FREE_RATE) / port_volatility if port_volatility > 0 else np.nan
    return port_return, port_volatility, port_sharpe


def negative_sharpe(weights: np.ndarray, annual_return: pd.Series, cov_matrix: pd.DataFrame) -> float:
    return -portfolio_performance(weights, annual_return, cov_matrix)[2]


def optimize_max_sharpe(annual_return: pd.Series, cov_matrix: pd.DataFrame) -> np.ndarray:
    asset_count = len(annual_return)
    initial_weights = np.repeat(1 / asset_count, asset_count)
    bounds = tuple((0, 1) for _ in range(asset_count))
    constraints = {"type": "eq", "fun": lambda weights: np.sum(weights) - 1}

    result = minimize(
        negative_sharpe,
        initial_weights,
        args=(annual_return, cov_matrix),
        method="SLSQP",
        bounds=bounds,
        constraints=constraints,
        options={"maxiter": 1000},
    )

    if not result.success:
        return initial_weights
    return result.x


def simulate_portfolios(annual_return: pd.Series, cov_matrix: pd.DataFrame, n_simulations: int = 3000) -> pd.DataFrame:
    rng = np.random.default_rng(42)
    records = []
    asset_count = len(annual_return)

    for _ in range(n_simulations):
        weights = rng.random(asset_count)
        weights = weights / weights.sum()
        port_return, port_volatility, port_sharpe = portfolio_performance(weights, annual_return, cov_matrix)
        records.append({
            "Return": port_return,
            "Volatility": port_volatility,
            "Sharpe Ratio": port_sharpe,
            "Weights": weights,
        })

    return pd.DataFrame(records)


def max_drawdown(series: pd.Series) -> float:
    cumulative_max = series.cummax()
    drawdown = (series / cumulative_max) - 1
    return float(drawdown.min())


def build_portfolio_curve(returns: pd.DataFrame, weights: np.ndarray) -> pd.Series:
    portfolio_returns = returns.dot(weights)
    return (1 + portfolio_returns).cumprod()


def moving_average_backtest(price_series: pd.Series, short_window: int, long_window: int) -> pd.DataFrame:
    frame = pd.DataFrame({"Price": price_series}).dropna()
    frame["Short MA"] = frame["Price"].rolling(short_window).mean()
    frame["Long MA"] = frame["Price"].rolling(long_window).mean()
    frame["Signal"] = np.where(frame["Short MA"] > frame["Long MA"], 1, 0)
    frame["Strategy Return"] = frame["Price"].pct_change() * frame["Signal"].shift(1)
    frame["Buy & Hold"] = (1 + frame["Price"].pct_change().fillna(0)).cumprod()
    frame["MA Strategy"] = (1 + frame["Strategy Return"].fillna(0)).cumprod()
    return frame.dropna()


with st.sidebar:
    st.header("Inputs")
    raw_tickers = st.text_area("Stock tickers", DEFAULT_TICKERS, height=100)
    col_a, col_b = st.columns(2)
    with col_a:
        start_date = st.date_input("Start date", date.today() - timedelta(days=365 * 3))
    with col_b:
        end_date = st.date_input("End date", date.today())
    simulation_count = st.slider("Monte Carlo portfolios", 500, 10000, 3000, 500)
    short_ma = st.slider("Short moving average", 5, 100, 20, 5)
    long_ma = st.slider("Long moving average", 30, 250, 100, 10)
    run_button = st.button("Run analysis", type="primary")

if not run_button:
    st.info("Enter 10-20 tickers in the sidebar and click Run analysis.")
    st.stop()

tickers = parse_tickers(raw_tickers)

if len(tickers) < 2:
    st.error("Please enter at least 2 valid tickers separated by commas.")
    st.stop()

if start_date >= end_date:
    st.error("Start date must be earlier than end date.")
    st.stop()

with st.spinner("Downloading price data and calculating portfolio analytics..."):
    prices = download_prices(tuple(tickers), start_date, end_date)

if prices.empty or prices.shape[1] < 2:
    st.error("Could not download enough valid price data. Check the ticker symbols and internet connection.")
    st.stop()

missing_tickers = sorted(set(tickers) - set(prices.columns))
if missing_tickers:
    st.warning(f"These tickers had no usable data and were skipped: {', '.join(missing_tickers)}")

returns = calculate_returns(prices)
annual_return, annual_volatility, sharpe = annualized_metrics(returns)
cov_matrix = returns.cov() * TRADING_DAYS
asset_count = len(prices.columns)
equal_weights = np.repeat(1 / asset_count, asset_count)
optimized_weights = optimize_max_sharpe(annual_return, cov_matrix)
simulations = simulate_portfolios(annual_return, cov_matrix, simulation_count)

eq_return, eq_vol, eq_sharpe = portfolio_performance(equal_weights, annual_return, cov_matrix)
opt_return, opt_vol, opt_sharpe = portfolio_performance(optimized_weights, annual_return, cov_matrix)

st.subheader("Portfolio summary")
metric_cols = st.columns(6)
metric_cols[0].metric("Assets analyzed", asset_count)
metric_cols[1].metric("Equal-weight return", f"{eq_return:.2%}")
metric_cols[2].metric("Equal-weight volatility", f"{eq_vol:.2%}")
metric_cols[3].metric("Equal-weight Sharpe", f"{eq_sharpe:.2f}")
metric_cols[4].metric("Optimized return", f"{opt_return:.2%}")
metric_cols[5].metric("Optimized Sharpe", f"{opt_sharpe:.2f}")

asset_table = pd.DataFrame({
    "Ticker": prices.columns,
    "Annual Return": annual_return.values,
    "Annual Volatility": annual_volatility.values,
    "Sharpe Ratio": sharpe.values,
    "Optimized Weight": optimized_weights,
    "Equal Weight": equal_weights,
}).sort_values("Optimized Weight", ascending=False)

st.dataframe(
    asset_table.style.format({
        "Annual Return": "{:.2%}",
        "Annual Volatility": "{:.2%}",
        "Sharpe Ratio": "{:.2f}",
        "Optimized Weight": "{:.2%}",
        "Equal Weight": "{:.2%}",
    }),
    use_container_width=True,
)

tab1, tab2, tab3, tab4 = st.tabs(["Risk-return map", "Allocation", "Performance", "Backtest"])

with tab1:
    fig = px.scatter(
        simulations,
        x="Volatility",
        y="Return",
        color="Sharpe Ratio",
        title="Monte Carlo simulated portfolios",
        hover_data={"Volatility": ":.2%", "Return": ":.2%", "Sharpe Ratio": ":.2f"},
    )
    fig.add_trace(go.Scatter(
        x=[eq_vol], y=[eq_return], mode="markers+text", name="Equal Weight",
        text=["Equal"], textposition="top center", marker=dict(size=14, symbol="diamond")
    ))
    fig.add_trace(go.Scatter(
        x=[opt_vol], y=[opt_return], mode="markers+text", name="Optimized",
        text=["Max Sharpe"], textposition="top center", marker=dict(size=16, symbol="star")
    ))
    fig.update_layout(xaxis_tickformat=".0%", yaxis_tickformat=".0%")
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    allocation = asset_table[["Ticker", "Optimized Weight"]].copy()
    fig = px.bar(allocation, x="Ticker", y="Optimized Weight", title="Optimized portfolio weights")
    fig.update_layout(yaxis_tickformat=".0%")
    st.plotly_chart(fig, use_container_width=True)

with tab3:
    equal_curve = build_portfolio_curve(returns, equal_weights)
    optimized_curve = build_portfolio_curve(returns, optimized_weights)
    performance = pd.DataFrame({
        "Equal Weight": equal_curve,
        "Optimized Portfolio": optimized_curve,
    })
    fig = px.line(performance, title="Cumulative portfolio growth")
    st.plotly_chart(fig, use_container_width=True)

    perf_cols = st.columns(2)
    perf_cols[0].metric("Equal-weight max drawdown", f"{max_drawdown(equal_curve):.2%}")
    perf_cols[1].metric("Optimized max drawdown", f"{max_drawdown(optimized_curve):.2%}")

with tab4:
    selected_ticker = st.selectbox("Choose a stock for moving-average backtest", list(prices.columns))
    if short_ma >= long_ma:
        st.warning("Short moving average should be lower than long moving average for a standard crossover strategy.")
    backtest = moving_average_backtest(prices[selected_ticker], short_ma, long_ma)
    fig = px.line(backtest[["Buy & Hold", "MA Strategy"]], title=f"Moving-average strategy vs buy-and-hold: {selected_ticker}")
    st.plotly_chart(fig, use_container_width=True)

    strategy_total_return = backtest["MA Strategy"].iloc[-1] - 1
    buy_hold_total_return = backtest["Buy & Hold"].iloc[-1] - 1
    backtest_cols = st.columns(2)
    backtest_cols[0].metric("MA strategy total return", f"{strategy_total_return:.2%}")
    backtest_cols[1].metric("Buy & hold total return", f"{buy_hold_total_return:.2%}")

st.download_button(
    "Download metrics as CSV",
    data=asset_table.to_csv(index=False).encode("utf-8"),
    file_name="portfolio_metrics.csv",
    mime="text/csv",
)

st.caption("Educational project only. This dashboard does not provide financial advice.")
