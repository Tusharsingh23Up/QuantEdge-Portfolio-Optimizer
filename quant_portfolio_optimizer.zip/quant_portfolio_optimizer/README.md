# Quant Portfolio Optimizer

A browser-based Python dashboard for portfolio and quantitative-finance analysis. The app helps users download stock price data, calculate return and risk metrics, simulate portfolios, optimize asset weights, and compare portfolio performance against an equal-weight benchmark.

## What this project does

This project is built for finance/data analyst portfolios. It demonstrates practical investment analytics using Python:

- Downloads historical stock data using Yahoo Finance
- Calculates daily returns, annualized return, volatility, Sharpe ratio, and max drawdown
- Builds an equal-weight portfolio benchmark
- Runs Monte Carlo portfolio simulations
- Finds an optimized portfolio using maximum Sharpe ratio logic
- Shows allocation weights in a clean chart
- Displays cumulative portfolio performance
- Includes a moving-average crossover backtest for one selected stock
- Works locally in the browser using Streamlit

## Tech stack

- Python
- Streamlit
- Pandas
- NumPy
- SciPy
- Plotly
- yFinance

## Folder structure

```text
quant_portfolio_optimizer/
│
├── app.py                 # Main Streamlit dashboard
├── requirements.txt       # Python dependencies
├── README.md              # Project documentation
└── .gitignore             # Files ignored by Git
```

## How to run locally in Cursor

### 1. Open the folder in Cursor

Open Cursor, then open this project folder:

```text
quant_portfolio_optimizer
```

### 2. Create a virtual environment

For Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\activate
```

For Mac/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the dashboard

```bash
streamlit run app.py
```

The app will open in your browser, usually at:

```text
http://localhost:8501
```

## Suggested stock inputs

You can start with:

```text
AAPL, MSFT, GOOGL, AMZN, NVDA, META, JPM, V, UNH, XOM
```

For Indian stocks, use Yahoo Finance NSE tickers:

```text
RELIANCE.NS, TCS.NS, INFY.NS, HDFCBANK.NS, ICICIBANK.NS, LT.NS, SBIN.NS, AXISBANK.NS, ITC.NS, BHARTIARTL.NS
```

## Key finance concepts used

### Annualized return

Average daily return converted into yearly return using approximately 252 trading days.

### Annualized volatility

Standard deviation of daily returns converted into yearly risk.

### Sharpe ratio

A risk-adjusted return metric. Higher Sharpe ratio means better return per unit of risk.

### Maximum drawdown

The largest percentage fall from a portfolio peak to its lowest point.

### Efficient frontier idea

The app simulates many possible portfolios to show how risk and return change with different allocations.

## GitHub repository description

Browser-based Python dashboard for portfolio optimization, risk-return analytics, Monte Carlo simulation, Sharpe ratio optimization, and moving-average backtesting using Streamlit.

## Good GitHub topics

```text
python, streamlit, finance, portfolio-optimization, quantitative-finance, risk-analysis, sharpe-ratio, monte-carlo, yfinance, data-analysis
```

## Future improvements

- Add Black-Litterman portfolio optimization
- Add risk parity allocation
- Add sector-level diversification analysis
- Add downloadable PDF investment report
- Add benchmark comparison with NIFTY 50 or S&P 500
- Add value-at-risk and conditional value-at-risk

## Disclaimer

This project is for educational and portfolio-building purposes only. It is not financial advice.
