# Repository name

quant-portfolio-optimizer

# Short description

Browser-based Python dashboard for portfolio optimization, Monte Carlo simulation, risk-return analytics, Sharpe ratio optimization, and moving-average backtesting using Streamlit.

# About section

A finance analytics dashboard that helps users compare stocks, calculate risk-return metrics, simulate thousands of portfolios, optimize weights for maximum Sharpe ratio, and test a moving-average strategy locally in the browser.

# Topics

python, streamlit, finance, quantitative-finance, portfolio-optimization, monte-carlo, sharpe-ratio, risk-analysis, yfinance, data-analysis

# Suggested commit message

Add Streamlit portfolio optimization dashboard

# GitHub push commands

```bash
git init
git add .
git commit -m "Add Streamlit portfolio optimization dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/quant-portfolio-optimizer.git
git push -u origin main
```
